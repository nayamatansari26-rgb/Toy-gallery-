import React from 'https://esm.sh/react';
import ReactDOM from 'https://esm.sh/react-dom';
import ToyStore from './ToyStore.js';

ReactDOM.render(React.createElement(ToyStore), document.getElementById('root'));
