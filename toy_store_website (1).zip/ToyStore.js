import { useState } from 'https://esm.sh/react';

export default function ToyStore() {
  const [language, setLanguage] = useState('en');

  const text = {
    en: {
      title: 'Welcome to Toy Store!',
      subtitle: 'Fun Toys for Kids — Shop Now',
      addToCart: 'Add to cart',
      price: 'Price',
      buyNow: 'Buy Now',
      langSwitch: 'Switch to Hindi',
      pay: 'Pay using PhonePe / GPay',
    },
    hi: {
      title: 'खिलौनों की दुनिया में आपका स्वागत है!',
      subtitle: 'बच्चों के लिए मजेदार खिलौने — अभी खरीदें',
      addToCart: 'कार्ट में जोड़ें',
      price: 'कीमत',
      buyNow: 'अभी खरीदें',
      langSwitch: 'Switch to English',
      pay: 'PhonePe / GPay से भुगतान करें',
    },
  };

  const products = [
    { id: 1, name: 'Toy Car', price: '₹499', img: 'https://i.imgur.com/Z6bSgFJ.png' },
    { id: 2, name: 'Magic Swing Car', price: '₹1,499', img: 'https://i.imgur.com/w4XUijg.png' },
    { id: 3, name: 'Baby Jeep', price: '₹2,499', img: 'https://i.imgur.com/ZsTCjIa.png' },
  ];

  return (
    React.createElement('div', { style: { fontFamily: 'sans-serif', padding: 20 } },
      React.createElement('header', { style: { background: '#9333EA', color: 'white', padding: 10, display: 'flex', justifyContent: 'space-between' } },
        React.createElement('h1', null, 'Toy Store'),
        React.createElement('button', { onClick: () => setLanguage(language === 'en' ? 'hi' : 'en'), style: { background: 'white', color: '#9333EA', padding: '5px 10px', borderRadius: 5 } },
          text[language].langSwitch
        )
      ),
      React.createElement('section', { style: { textAlign: 'center', marginTop: 20 } },
        React.createElement('h2', { style: { fontSize: 24, fontWeight: 'bold', color: '#9333EA' } }, text[language].title),
        React.createElement('p', { style: { color: '#555', marginTop: 5 } }, text[language].subtitle)
      ),
      React.createElement('div', { style: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: 20, marginTop: 20 } },
        products.map(item =>
          React.createElement('div', { key: item.id, style: { background: 'white', borderRadius: 10, boxShadow: '0 2px 8px rgba(0,0,0,0.1)', padding: 20, textAlign: 'center' } },
            React.createElement('img', { src: item.img, style: { width: 150, height: 150, objectFit: 'contain', marginBottom: 10 } }),
            React.createElement('h3', { style: { fontSize: 18, fontWeight: 'bold' } }, item.name),
            React.createElement('p', { style: { color: '#9333EA', fontWeight: 'bold', marginTop: 5 } }, text[language].price + ': ' + item.price),
            React.createElement('button', { style: { background: '#9333EA', color: 'white', padding: '8px 15px', marginTop: 10, borderRadius: 5 } },
              text[language].addToCart
            )
          )
        )
      ),
      React.createElement('footer', { style: { background: '#f1f1f1', marginTop: 30, padding: 20, textAlign: 'center' } },
        React.createElement('p', null, text[language].pay),
        React.createElement('a', { href: 'tel:+919999999999', style: { background: '#10B981', color: 'white', padding: '10px 20px', borderRadius: 30, textDecoration: 'none' } }, '📞 PhonePe / GPay UPI')
      )
    )
  );
}
